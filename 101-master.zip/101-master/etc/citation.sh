cat<<EOF
# CITATION

Please cite this as

- T. Menzies, "DUO 101: An Introduction to Data Mining using/used-by Optimizers", 2018

Bibtex:

    @misc{$What$When,
      author="$Who",
      year="$When",
      title="$What",
      note="Download from http://github.com/$Repo"
    }
EOF
