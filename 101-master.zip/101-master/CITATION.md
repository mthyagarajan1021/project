# CITATION

Please cite this as

- T. Menzies, "DUO 101: An Introduction to Data Mining using/used-by Optimizers", 2018

Bibtex:

    @misc{Duo1012018,
      author="Tim Menzies",
      year="2018",
      title="Duo101",
      note="Download from http://github.com/d-u-o/101"
    }
