# Data mining Using/Used-by Optimizers

Some demonstration code of pipelines in DUO (data mining using/used-by optimizers).

e.g.

```
data | dom | label | discretize | best
```

## Install

First install lua, luajit, pycco using your local package manager. Eg

```
brew install lua 
brew install luajit 
sudo -H pip install pycco
```
Now:
```
cd src

../etc/ide

```
## Running

From then on, just

```
cd src
../etc/ide
```
